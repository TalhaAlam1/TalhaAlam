import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from transformers import pipeline
import numpy as np
import PyPDF2
import pickle

with open('vectorizer.pkl', 'rb') as f:
  vectorizer = pickle.load(f)
with open('doc_vectors.pkl', 'rb') as f:
  doc_vectors = pickle.load(f)

# Load an image for the header (optional)
header_image = None  # You can set this to an actual image path if desired

# Page configuration
st.set_page_config(
    page_title="PDF Q&A RAG App",
    page_icon="📄",
    layout="centered",
    initial_sidebar_state="auto",
)

# Custom CSS for styling
st.markdown(
    """
    <style>
    .main {
        background-color: #f5f5f5;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }
    .title {
        font-family: 'Arial Black', sans-serif;
        color: #4F8A8B;
        text-align: center;
    }
    .question-input {
        font-size: 1.2em;
        padding: 10px;
        border-radius: 5px;
        border: 2px solid #4F8A8B;
    }
    .answer-box {
        margin-top: 20px;
        padding: 15px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
    }
    .submit-button {
        background-color: #4F8A8B;
        color: white;
        font-size: 1.2em;
        padding: 10px 20px;
        border-radius: 5px;
        margin-top: 20px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Function to extract text from a PDF
def extract_text_from_pdf(pdf_file):
    reader = PyPDF2.PdfReader(pdf_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

# Function to retrieve the most relevant paragraph
def retrieve_document(query, paragraphs, vectorizer, doc_vectors):
    query_vector = vectorizer.transform([query])
    similarities = np.dot(doc_vectors, query_vector.T).toarray().flatten()
    best_match_index = similarities.argmax()
    return paragraphs[best_match_index]

# Initialize QA model
qa_pipeline = pipeline("question-answering", model="bert-large-uncased-whole-word-masking-finetuned-squad")

# Display header image (optional)
if header_image:
    st.image(header_image, use_column_width=True)

# App title
st.markdown("<h1 class='title'>PDF Q&A Retrieval-Augmented Generation App</h1>", unsafe_allow_html=True)

# File uploader
uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

if uploaded_file is not None:
    # Extract text from the uploaded PDF
    with st.spinner("Extracting text from PDF..."):
        pdf_text = extract_text_from_pdf(uploaded_file)

    # Split the text into paragraphs
    paragraphs = pdf_text.split('\n\n')

    # Vectorize the paragraphs
    vectorizer = TfidfVectorizer()
    doc_vectors = vectorizer.fit_transform(paragraphs)

    # User input
    st.markdown("<p><b>Ask a question:</b></p>", unsafe_allow_html=True)
    question = st.text_input("", key="question_input", max_chars=200, help="Type your question here...")

    # Submit button
    if st.button("Get Answer", key="submit_button"):
        if question:
            # Retrieve the most relevant document
            relevant_doc = retrieve_document(question, paragraphs, vectorizer, doc_vectors)
            
            # Generate an answer using the QA model
            with st.spinner("Generating answer..."):
                result = qa_pipeline(question=question, context=relevant_doc)
                answer = result['answer']

            st.markdown(f"<div class='answer-box'><b>Answer:</b><br>{answer}</div>", unsafe_allow_html=True)
        else:
            st.warning("Please enter a question.")

# Footer
st.markdown(
    """
    <hr>
    <div style='text-align: center;'>
    <small>Powered by Streamlit and Transformers • © 2024 Your Name</small>
    </div>
    """,
    unsafe_allow_html=True,
)
