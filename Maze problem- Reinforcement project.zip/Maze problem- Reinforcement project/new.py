import tkinter as tk
import numpy as np
import random

class CatMouseEnv:
    def __init__(self, grid_size=10):
        self.grid_size = grid_size
        self.reset()
        
    def reset(self):
        self.cat_pos = [random.randint(0, self.grid_size-1), random.randint(0, self.grid_size-1)]
        self.mouse_pos = [random.randint(0, self.grid_size-1), random.randint(0, self.grid_size-1)]
        return self.get_state()
        
    def get_state(self):
        return (self.cat_pos[0], self.cat_pos[1], self.mouse_pos[0], self.mouse_pos[1])
    
    def step(self, action):
        if action == 0 and self.cat_pos[1] > 0:
            self.cat_pos[1] -= 1
        elif action == 1 and self.cat_pos[1] < self.grid_size-1:
            self.cat_pos[1] += 1
        elif action == 2 and self.cat_pos[0] > 0:
            self.cat_pos[0] -= 1
        elif action == 3 and self.cat_pos[0] < self.grid_size-1:
            self.cat_pos[0] += 1
        
        reward = -1
        if self.cat_pos == self.mouse_pos:
            reward = 100
            done = True
        else:
            done = False
            
        return self.get_state(), reward, done

class CatMouseApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Cat vs Mouse RL Game")
        self.grid_size = 10
        self.cell_size = 50
        self.env = CatMouseEnv(grid_size=self.grid_size)
        self.canvas = tk.Canvas(self.master, width=self.grid_size*self.cell_size, height=self.grid_size*self.cell_size)
        self.canvas.pack()
        self.q_table = np.zeros((self.grid_size, self.grid_size, self.grid_size, self.grid_size, 4))
        self.learning_rate = 0.1
        self.discount_factor = 0.9
        self.epsilon = 0.1
        self.num_episodes = 1000
        self.create_grid()
        self.train_model()
        self.reset_game()
        
    def create_grid(self):
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                self.canvas.create_rectangle(i*self.cell_size, j*self.cell_size, (i+1)*self.cell_size, (j+1)*self.cell_size, outline="black")
    
    def draw_cat_mouse(self):
        self.canvas.delete("cat")
        self.canvas.delete("mouse")
        self.canvas.create_oval(self.env.cat_pos[0]*self.cell_size, self.env.cat_pos[1]*self.cell_size,
                                (self.env.cat_pos[0]+1)*self.cell_size, (self.env.cat_pos[1]+1)*self.cell_size, fill="blue", tags="cat")
        self.canvas.create_oval(self.env.mouse_pos[0]*self.cell_size, self.env.mouse_pos[1]*self.cell_size,
                                (self.env.mouse_pos[0]+1)*self.cell_size, (self.env.mouse_pos[1]+1)*self.cell_size, fill="red", tags="mouse")
    
    def train_model(self):
        for episode in range(self.num_episodes):
            state = self.env.reset()
            done = False
            
            while not done:
                if random.uniform(0, 1) < self.epsilon:
                    action = random.randint(0, 3)
                else:
                    action = np.argmax(self.q_table[state])
                
                next_state, reward, done = self.env.step(action)
                
                old_value = self.q_table[state][action]
                next_max = np.max(self.q_table[next_state])
                
                new_value = old_value + self.learning_rate * (reward + self.discount_factor * next_max - old_value)
                self.q_table[state][action] = new_value
                
                state = next_state
    
    def reset_game(self):
        self.state = self.env.reset()
        self.draw_cat_mouse()
        self.master.after(1000, self.play_game)
    
    def play_game(self):
        action = np.argmax(self.q_table[self.state])
        self.state, reward, done = self.env.step(action)
        self.draw_cat_mouse()
        if not done:
            self.master.after(500, self.play_game)
        else:
            self.master.after(1000, self.reset_game)

if __name__ == "__main__":
    root = tk.Tk()
    app = CatMouseApp(root)
    root.mainloop()
