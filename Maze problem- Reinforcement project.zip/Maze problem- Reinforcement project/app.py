from maze_env import Maze
from RL_agent import QLearningTable
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

episode_count = 50 # Number of episodes to run the experiment
episodes = range(episode_count)
movements = [] # Number of movements happened in each episode
rewards = [] # The gained reward in each episode

def run_experiment():

    for episode in episodes:
        print("Episode %s/%s." %(episode+1, episode_count))
        # initial observation;
        observation = env.reset()
        moves = 0

        while True:
            # fresh env
            env.render()

            # Q-learning chooses action based on observation
            # we convert observation to str since we want to use them as index for our DataFrame.
            action = q_learning_agent.choose_action(str(observation)) # ToDo: call choose_action() method from the agent QLearningTable instance

            # RL takes action and gets next observation and reward
            observation_, reward, done = env.get_state_reward(action) # ToDo: call get_state_reward() method from Maze environment instance
            moves +=1

            # RL learn from the above transition,
            # Update the Q value for the given tuple
            q_learning_agent.learn(str(observation), action, reward, str(observation_))# ToDo: call learn method from Q-learning agent instance, passing (s, a, r, s') tuple

            # consider the next observation
            observation = observation_

            # break while loop when end of this episode
            if done:
                movements.append(moves) # Keep track of the number of movements in this episode
                rewards.append(reward) # Keep track of the gained reward in this episode
                print("Reward: {0}, Moves: {1}".format(reward, moves))
                break

    # end of game
    print('game over!')
    # Show the results
    plot_reward_movements()

def plot_reward_movements():
    plt.figure()
    plt.subplot(2,1,1)
    plt.plot(episodes, movements)
    plt.xlabel("Episode")
    plt.ylabel("# Movements")

    plt.subplot(2,1,2)
    plt.step(episodes, rewards)
    plt.xlabel("Episode")
    plt.ylabel("Reward")
    plt.savefig("rewards_movements_q_learn.png")
    plt.show()


if __name__ == "__main__":
    env = Maze() 
    q_learning_agent = QLearningTable(actions=list(range(env.n_actions))) 
    env.window.after(10, run_experiment)
    env.window.mainloop()
