import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import LabelEncoder


# Load the saved models
lr_model = pickle.load(open('C:/Users/Acer/Desktop/projects/archive (14)/logistic_regression_model.sav', 'rb'))
#dt_model = pickle.load(open('decision_tree_model.sav', 'rb'))
le = pickle.load(open('C:/Users/Acer/Desktop/projects/archive (14)/label_encoder_model.sav', 'rb'))

st.title("Netflix Churn Prediction App")

# Create input fields for user data
subscription_type = st.selectbox("Subscription Type", ['Basic', 'Standard', 'Premium'])
country = st.selectbox("Country", ['United States', 'Canada', 'United Kingdom', 'Mexico', 'Brazil', 'India', 'France', 'Germany', 'Japan', 'Australia'])
gender = st.selectbox("Gender", ['Male', 'Female'])
device = st.selectbox("Device", ['Mobile', 'Tablet', 'TV', 'Computer'])
age_group = st.selectbox("Age Group", ['18-25', '26-35', '36-45', '46-55', '56-65', '65+'])
age = st.number_input("Age", min_value=18, max_value=100, value=25)
monthly_revenue = st.number_input("Monthly Revenue", min_value=0, value=10)
plan_duration = st.number_input("Plan Duration (Months)", min_value=1, value=1)


# Create a button to trigger the prediction
if st.button("Predict Churn"):
    # Prepare the input data as a DataFrame
    input_data = pd.DataFrame({
        'Subscription Type': [subscription_type],
        'Country': [country],
        'Gender': [gender],
        'Device': [device],
        'Age Group': [age_group],
        'Age': [age],
        'Monthly Revenue': [monthly_revenue],
        'Plan Duration (Months)': [plan_duration]
    })

    # Encode the categorical features
    for column in ['Subscription Type', 'Country', 'Gender', 'Device', 'Age Group']:
      input_data[column] = le.transform(input_data[column].astype(str))

    # Make predictions using the loaded models
    lr_prediction = lr_model.predict(input_data)[0]
    #dt_prediction = dt_model.predict(input_data)[0]

    # Display the predictions
    st.subheader("Prediction Results:")

    st.write("**Logistic Regression Prediction:**", "Churn" if lr_prediction == 1 else "Not Churn")
    #st.write("**Decision Tree Prediction:**", "Churn" if dt_prediction == 1 else "Not Churn")
