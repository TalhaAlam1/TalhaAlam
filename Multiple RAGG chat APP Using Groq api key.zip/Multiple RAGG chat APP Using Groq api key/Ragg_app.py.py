import os
import streamlit as st
from groq import Groq
import fitz  # PyMuPDF for PDF handling
from docx import Document
import io

# Directly set your Groq API key here
API_KEY = "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"

# Initialize the Groq client
client = Groq(api_key=API_KEY)

# Function to extract text from PDF
def extract_text_from_pdf(file):
    doc = fitz.open(stream=file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    return text

# Function to extract text from DOCX
def extract_text_from_docx(file):
    doc = Document(io.BytesIO(file.read()))
    text = ""
    for para in doc.paragraphs:
        text += para.text + "\n"
    return text

# Function to get the response from Groq
def get_response_from_documents(query, documents):
    messages = [{"role": "system", "content": "You are a helpful assistant."}]
    
    # Append document content as context for the assistant
    for doc in documents:
        messages.append({"role": "system", "content": f"Document content: {doc}"})
    
    messages.append({"role": "user", "content": query})
    
    chat_completion = client.chat.completions.create(
        messages=messages,
        model="mixtral-8x7b-32768",
    )
    return chat_completion.choices[0].message.content

# Streamlit app layout
st.title("RAGG Application")

# Upload documents
uploaded_files = st.file_uploader("Upload your documents", type=["pdf", "docx", "txt"], accept_multiple_files=True)

documents = []
if uploaded_files:
    for uploaded_file in uploaded_files:
        if uploaded_file.type == "application/pdf":
            content = extract_text_from_pdf(uploaded_file)
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            content = extract_text_from_docx(uploaded_file)
        else:
            content = uploaded_file.read().decode("utf-8")
        
        documents.append(content)
        st.write(f"Uploaded document: {uploaded_file.name}")

# Query input
query = st.text_input("Enter your query")

if st.button("Get Response"):
    if query and documents:
        # Get response from Groq
        response = get_response_from_documents(query, documents)
        
        # Display the response
        st.write("Response:")
        st.write(response)
    else:
        st.write("Please upload documents and enter a query.")
