import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from surprise import Dataset, Reader, SVD, accuracy
from surprise.model_selection import train_test_split

# Load data
data_path = 'retail_sales_dataset.csv'
data = pd.read_csv(data_path)

# Preprocessing
data['Age Group'] = pd.cut(data['Age'], bins=[0, 18, 35, 50, 70, 100], labels=['0-18', '19-35', '36-50', '51-70', '71+'])
data['Product Info'] = data['Product Category'] + ' ' + data['Gender'] + ' ' + data['Age Group'].astype(str)

def get_content_based_recommendations(product_id, num_recommendations):
    cosine_similarities = linear_kernel(tfidf_matrix[product_id:product_id+1], tfidf_matrix).flatten()
    related_docs_indices = cosine_similarities.argsort()[-num_recommendations-1:-1][::-1]
    return data['Product Category'].iloc[related_docs_indices].unique()


# Content-Based Filtering
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(data['Product Info'])

def get_recommendations(product_id, num_recommendations):
    cosine_similarities = linear_kernel(tfidf_matrix[product_id:product_id+1], tfidf_matrix).flatten()
    related_docs_indices = cosine_similarities.argsort()[-num_recommendations-1:-1][::-1]
    return data['Product Category'].iloc[related_docs_indices]

# Collaborative Filtering using SVD
reader = Reader(rating_scale=(data['Total Amount'].min(), data['Total Amount'].max()))
surprise_data = Dataset.load_from_df(data[['Transaction ID', 'Product Category', 'Total Amount']], reader)
trainset, testset = train_test_split(surprise_data, test_size=0.2)

svd_model = SVD()
svd_model.fit(trainset)

predictions = svd_model.test(testset)
rmse = accuracy.rmse(predictions)

# Streamlit App
st.title('Retail Sales Product Recommendation System')

st.sidebar.header('Choose Recommendation Type')
recommendation_type = st.sidebar.radio('Type', ('Content-Based', 'Collaborative Filtering'))

if recommendation_type == 'Content-Based':
    st.header('Content-Based Recommendation System')
    st.write('Recommend products based on product information and demographics.')
    
    # Display sample products for reference
    st.subheader('Sample Products')
    sample_products = data[['Transaction ID', 'Product Category', 'Gender', 'Age Group']].drop_duplicates().head(10)
    st.write(sample_products)
    
    # Input: Select Product ID
    product_id = st.number_input(
        'Enter Product ID for Recommendation',
        min_value=0,
        max_value=len(data)-1,
        value=0,
        step=1
    )
    
    num_recommendations = st.slider(
        'Number of Recommendations',
        min_value=1,
        max_value=10,
        value=5
    )
    
    if st.button('Get Recommendations'):
        recommended_products = get_content_based_recommendations(product_id, num_recommendations)
        st.write('### Recommended Products:')
        for i, product in enumerate(recommended_products, start=1):
            st.write(f'{i}. {product}')

elif recommendation_type == 'Collaborative Filtering':
    st.header('Collaborative Filtering Recommendation System')
    st.write('Recommendation using SVD based on customer purchase behavior.')
    
    # Select Customer ID
    customer_id = st.selectbox(
        'Select Customer ID for Recommendation', 
        sorted(data['Customer ID'].unique())
    )
    
    if st.button('Get Recommendations'):
        # Get all unique products
        all_products = data['Product Category'].unique()
        
        # Get products already purchased by the customer
        purchased_products = data[data['Customer ID'] == customer_id]['Product Category'].unique()
        
        # Identify products not yet purchased
        products_to_recommend = [prod for prod in all_products if prod not in purchased_products]
        
        if not products_to_recommend:
            st.write('No new products to recommend. Customer has purchased all available products.')
        else:
            # Predict ratings for products not yet purchased
            recommendations = []
            for product in products_to_recommend:
                pred = svd_model.predict(customer_id, product)
                recommendations.append({'Product Category': product, 'Estimated': pred.est})
            
            # Create DataFrame from recommendations
            recommendations_df = pd.DataFrame(recommendations)
            
            # Get top 5 recommendations sorted by estimated rating
            top_recommendations = recommendations_df.sort_values(by='Estimated', ascending=False).head(5)
            
            st.write('### Top 5 Recommended Products based on Estimated Total Amount:')
            for idx, row in top_recommendations.iterrows():
                st.write(f"{row['Product Category']} with estimated amount: ${row['Estimated']:.2f}")

st.markdown("---")
st.write("© 2024 Retail Sales Recommendation System")

